#include "xc.h"
#include "sys/attribs.h"
#define CS LATBbits.LATB8       // chip select pin

void spi1_set(char channel,char voltage){
//result = (result << 24) | num3; concat code
char configbits = 0b111;
char pad = 0b0000;
configbits = (channel<<1)|configbits;
configbits = (configbits<<4)|voltage;
configbits = (configbits<<12)|pad;

spi1_write(configbits);

}
void spi1_start(void){
    CS = 1;
    //all defaults are 0
    SPI1CON = 0;
    SPI1BUF;
    SPI1BRG = 0x2399; //baud rate to 10khz
    SPI1STATbits.SPIROV = 0;
    SPI1CONbits.CKE = 1;
    SPI1CONbits.MODE16 = 0b01; //set for 16bit transfer
    SPI1CONbits.MSTEN = 1;
    SPI1CONbits.ON = 1; //turn on SPI1
}

void spi1_write(unsigned char data){
    CS = 0;
    SPI1BUF = data;
    
    while(!SPI1STATbits.SPIRBF){} //wait to receive byte in future
    CS = 1;
}
void spi1_stop(void){
    CS = 1; 
    SPI1CON = 0;
}