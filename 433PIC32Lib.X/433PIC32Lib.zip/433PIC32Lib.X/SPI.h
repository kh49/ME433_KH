#ifndef SPI_H__
#define SPI_H__


void sp1_set(char channel, char voltage)
void spi1_start(void);
void spi1_write(void);
void spi1_stop(void);

#endif